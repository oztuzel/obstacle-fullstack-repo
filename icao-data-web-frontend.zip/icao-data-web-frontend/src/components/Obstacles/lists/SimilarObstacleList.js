import React, { useState } from "react";
import ModalSimilarObstaclesRow from "../modal/ModalSimilarObstaclesRow";

function SimilarObstacleList({ similarObstacles }) {
  const itemsPerPage = 50; // Her sayfada gösterilecek öğe sayısı
  const [currentPage, setCurrentPage] = useState(1);
  const [obstacleData, setObstacleData] = useState(null);
  const [hgObstacleData, setHgObstacleData] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const similarObstacleKeys = Object.keys(similarObstacles);
  const currentItems = similarObstacleKeys
    .slice(indexOfFirstItem, indexOfLastItem)
    .map((obstacleId) => ({
      obstacleId,
      hgObstacleIds: similarObstacles[obstacleId],
    }));

  const totalPages = Math.ceil(
    Object.keys(similarObstacles).length / itemsPerPage
  );

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const fetchObstacleData = async (obstacleId) => {
    try {
      // /obstacles/{obstacleId} için istek gönder
      const obstacleResponse = await fetch(
        `http://localhost:8080/obstacles/${obstacleId}`
      );
      const obstacleData = await obstacleResponse.json();
      setObstacleData(obstacleData);
      // console.log("Obstacle Data:", obstacleData);
    } catch (error) {
      console.error("Error fetching obstacle data:", error);
    }
  };

  const fetchHgObstacleData = async (hgObstacleId) => {
    try {
      // /hgmobstacles/{hgObstacleId} için istek gönder
      const hgObstacleResponse = await fetch(
        `http://localhost:8080/HGMObstacles/${hgObstacleId}`
      );
      const hgObstacleData = await hgObstacleResponse.json();
      setHgObstacleData((prevData) => [...prevData, hgObstacleData]);
      // console.log("HG Obstacle Data:", hgObstacleData);
    } catch (error) {
      console.error("Error fetching HG obstacle data:", error);
    }
  };

  const handleRowClick = async (obstacleId, hgObstacleIds) => {
    // /obstacles/{obstacleId} için istek gönderiyoruz
    fetchObstacleData(obstacleId);

    // /hgmobstacles/{hgObstacleId} için her bir hgObstacleId için istek gönderiyoruz
    if (Array.isArray(hgObstacleIds)) {
      hgObstacleIds.forEach((hgObstacleId) => {
        fetchHgObstacleData(hgObstacleId);
      });
    }

    // tiklandiginda kutucuk acilacak ve datalari gosterecez.
    setIsModalOpen(true);
  };

  const closeModal = () => {
    // kutucuku kapatma yeri
    setIsModalOpen(false);
    setObstacleData(null);
    setHgObstacleData([]);
  };

  return (
    <div>
      <h2>Similar Obstacles:</h2>
      <table>
        <thead>
          <tr>
            <th>ENR 5.4 Obstacle ID</th>
            <th>HGM Obstacle IDs</th>
          </tr>
        </thead>
        <tbody>
          {currentItems.map(({ obstacleId, hgObstacleIds }, index) => (
            <tr
              key={index}
              onClick={() => handleRowClick(obstacleId, hgObstacleIds)}
            >
              <td>{obstacleId}</td>
              <td>{hgObstacleIds.join(", ")}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div>
        <p>
          Page {currentPage} of {totalPages}
        </p>
        <button
          onClick={() => handlePageChange(currentPage - 1)}
          disabled={currentPage === 1}
        >
          Previous
        </button>
        <button
          onClick={() => handlePageChange(currentPage + 1)}
          disabled={currentPage === totalPages}
        >
          Next
        </button>
      </div>

      {isModalOpen && (
        <ModalSimilarObstaclesRow
          obstacleData={obstacleData}
          hgObstacleData={hgObstacleData}
          closeModal={closeModal}
        />
      )}
    </div>
  );
}

export default SimilarObstacleList;
