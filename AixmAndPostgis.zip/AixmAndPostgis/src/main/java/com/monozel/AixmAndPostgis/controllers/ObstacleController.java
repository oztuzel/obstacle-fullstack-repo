package com.monozel.AixmAndPostgis.controllers;

import com.monozel.AixmAndPostgis.entities.Obstacle;
import com.monozel.AixmAndPostgis.requests.HGMObstacleRequest;
import com.monozel.AixmAndPostgis.requests.ObstacleDistanceRequest;
import com.monozel.AixmAndPostgis.requests.ObstacleRequest;
import com.monozel.AixmAndPostgis.services.ObstacleService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@AllArgsConstructor
@RequestMapping("/obstacles")
public class ObstacleController {

    private ObstacleService obstacleService;

    // Obstacle'lari database'den alip ObstacleRequest'e cevirip liste seklinde donduruyoruz.
    @GetMapping
    public List<ObstacleRequest> getAllObstacles () {
        List<Obstacle> obstacleList = obstacleService.getAllObstacles();
        List<ObstacleRequest> obstacleRequestList = new ArrayList<>();
        for(Obstacle obstacle: obstacleList) {
            obstacleRequestList.add(new ObstacleRequest(obstacle));
        }
        return obstacleRequestList;

    }

    @GetMapping("/{id}")
    public ObstacleRequest getHGMObstacleById(@PathVariable Long id) {
        return obstacleService.findById(id);
    }

    @GetMapping("/findSimilarPoints")
    public Map<Long, List<Long>> findSimilarObstacles () {
        return obstacleService.findSimilarPoints();

    }

    @GetMapping("/findPointsSameIntegerCoordinates")
    public Map<Long, List<Long>> findOtherSimilarObstacles() {
        System.out.println(obstacleService.findSamePointsWithInteger().size());
        return obstacleService.findSamePointsWithInteger();
    }

    @GetMapping("/nearestPoints")
    public  List<ObstacleDistanceRequest> findNearestTenHGMObstacles(@RequestParam("obstacleId") Long obstacleID){
        return obstacleService.findNearestTenPoints(obstacleID);
    }


    @GetMapping("/findObstaclesWithin30MetersForEach")
    public Map<Long,List<Long>> findObstaclesWithin30MetersForEach () {
        return obstacleService.findObstaclesWithin30MetersForEach();
    }

    @GetMapping("/findObstaclesWith30")
    public List<ObstacleRequest> findObstaclesWith30 () {
        return obstacleService.findObstaclesWith30();
    }


    @PostMapping
    public ResponseEntity<String> addObstacle(@RequestBody ObstacleRequest obstacleRequest) {

        Obstacle obstacle = obstacleService.createObstacleFromObstacleRequest(obstacleRequest);

        Obstacle savedObstacle = obstacleService.addOneObstacle(obstacle);

        return ResponseEntity.ok("Engel başarıyla kaydedildi. ID: " + savedObstacle.getId());

    }


}
