import { configureStore } from "@reduxjs/toolkit";
import obstacleSlice from "./obstacle-slice.js";
import mapSlice from "./map-slice.js";
import uiSlice from "./ui-slice.js";

const store = configureStore({
  reducer: {
    obstacle: obstacleSlice.reducer,
    map: mapSlice.reducer,
    ui: uiSlice.reducer,
  },
});

export default store;

// ileride redux'a tasiyacagim selectedPoint, obstacle'larin hepsini ve nearestPoints'leri yani obstacle'larla ilgili herseyi
