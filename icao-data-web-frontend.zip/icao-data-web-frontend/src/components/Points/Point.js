import React from 'react'

function Point({name,latitude, longitude,}) {
  return (
    <div>Point</div>
  )
}

export default Point