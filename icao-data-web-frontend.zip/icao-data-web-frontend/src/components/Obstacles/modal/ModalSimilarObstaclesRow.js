// ModalSimilarObstaclesRow.jsx

import React from "react";
import styles from "./ModalSimilarObstaclesRow.module.css";

function ModalSimilarObstaclesRow({
  obstacleData,
  hgObstacleData,
  closeModal,
}) {
  return (
    <div className={styles.modal}>
      <div className={styles.modalContent}>
        <div className={styles.contentWrapper}>
          <div className={styles.obstacleData}>
            <h3>Obstacle Data:</h3>
            {obstacleData && <pre>{JSON.stringify(obstacleData, null, 2)}</pre>}
          </div>
          <div className={styles.hgObstacleData}>
            <h3>HG Obstacle Data (30m secildiyse Obstacle Data): </h3>
            <div className={styles.scrollableArea}>
              {hgObstacleData.length > 0 &&
                hgObstacleData.map((hgData, index) => (
                  <div key={index}>
                    <pre>{JSON.stringify(hgData, null, 2)}</pre>
                  </div>
                ))}
            </div>
          </div>
        </div>
        <button className={styles.close} onClick={closeModal}>
          Kapat
        </button>
      </div>
    </div>
  );
}

export default ModalSimilarObstaclesRow;
