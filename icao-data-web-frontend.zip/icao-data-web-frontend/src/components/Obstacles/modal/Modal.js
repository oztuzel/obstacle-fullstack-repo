import React from "react";
import ObstacleDetail from "../details/ObstacleDetail";
import HGObstacleDetail from "../details/HGObstacleDetail";
import style from "./Modal.module.css";

function Modal({ obstacle, hgObstacle, closeModal }) {
  return (
    <div className={style.modalContainer}>
      <div className={style.modalContent}>
        <div className={style.left}>
          <ObstacleDetail obstacle={obstacle} />
        </div>
        <div className={style.right}>
          <HGObstacleDetail hgObstacle={hgObstacle} />
        </div>
      </div>
      <button onClick={closeModal}>Close</button>
    </div>
  );
}

export default Modal;
