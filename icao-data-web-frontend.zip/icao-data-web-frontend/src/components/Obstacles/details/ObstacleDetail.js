import React from "react";

function ObstacleDetail({ obstacle }) {
  return (
    <div className="modal">
      <div className="modal-content">
        <h2>ENR 5.4 Obstacle Details</h2>
        <p>Designator: {obstacle.designator}</p>
        <p>AIXM Name: {obstacle.aixm_name}</p>
        <p>Type: {obstacle.type}</p>
        <p>Height: {obstacle.height}</p>
        <p>Elevation: {obstacle.elevation}</p>
        <p>Lighting: {obstacle.lighting}</p>
        <p>Colour: {obstacle.colour}</p>
        <div>
          <p>Latitude: {obstacle.latitude} </p>
          <p>Latitude(DMS): {obstacle.latitudeDMS}</p>
        </div>
        <div>
          <p>Longitude: {obstacle.longitude}</p>
          <p>Longitude (DMS): {obstacle.longitudeDMS}</p>
        </div>

        <p>Group: {obstacle.group}</p>
      </div>
    </div>
  );
}

export default ObstacleDetail;
