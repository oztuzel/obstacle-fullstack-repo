import React, { useState } from "react";
import style from "./MatchedObstacleList.module.css";
import RowObstacle from "../RowObstacle";

function MatchedObstacleList({ matchedObstacles }) {
  const itemsPerPage = 50; // Her sayfada gösterilecek öğe sayısı
  const [currentPage, setCurrentPage] = useState(1);

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = matchedObstacles.slice(
    indexOfFirstItem,
    indexOfLastItem
  );

  const totalPages = Math.ceil(matchedObstacles.length / itemsPerPage);

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  return (
    <div className={style.tableContainer}>
      <h2>Matched Obstacles:</h2>
      <table>
        <thead>
          <tr>
            <th>ENR 5.4 Obstacle ID</th>
            <th>HGM Obstacle ID</th>
          </tr>
        </thead>
        <tbody>
          {currentItems.map(([obstacleId, hgObstacleId], index) => (
            <RowObstacle
              key={index}
              obstacleId={obstacleId}
              hgObstacleId={hgObstacleId}
            />
          ))}
        </tbody>
      </table>
      <div>
        <p>
          Page {currentPage} of {totalPages}
        </p>
        <button
          onClick={() => handlePageChange(currentPage - 1)}
          disabled={currentPage === 1}
        >
          Previous
        </button>
        <button
          onClick={() => handlePageChange(currentPage + 1)}
          disabled={currentPage === totalPages}
        >
          Next
        </button>
      </div>
    </div>
  );
}

export default MatchedObstacleList;
