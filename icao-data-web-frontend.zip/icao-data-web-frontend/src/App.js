import { Route, Routes } from "react-router";
import Navbar from "./components/Navbar/Navbar";
import Points from "./components/Points/Points";
import Obstacle from "./components/Obstacles/Obstacle";
import Map from "./components/Map/Map";
import Notification from "./components/UI/Notification";
import { useSelector } from "react-redux";

function App() {
  console.log("App component running");

  const notification = useSelector((state) => state.ui.notification);

  return (
    <div className="App">
      {notification && (
        <Notification
          status={notification.status}
          title={notification.title}
          message={notification.message}
        />
      )}
      <Routes>
        <Route path="/" element={<Navbar />} />
        <Route
          path="/points"
          element={
            <div>
              <Points />
            </div>
          }
        />
        <Route
          path="/obstacles"
          element={
            <div>
              <Navbar />
              <Obstacle />
            </div>
          }
        />
        <Route path="/map" element={<Map />} />
      </Routes>
    </div>
  );
}

export default App;
