import React, { useState } from "react";
import AddObstacle from "./add/AddObstacle";
import style from "./Obstacle.module.css";
import MatchedObstacleList from "./lists/MatchedObstacleList";
import SimilarObstacleList from "./lists/SimilarObstacleList";
import ObstaclesWithin30Meters from "./lists/ObstaclesWithin30Meters";
import { useSelector, useDispatch } from "react-redux";

import {
  fetchMatchedObstacles,
  fetchSimilarObstacles,
  fetchSameIntegerObstacles,
  fetchObstaclesWithin30m,
} from "../../store/obstacle-slice";
import { uiActions } from "../../store/ui-slice";
import Loading from "../UI/Loading";

function Obstacle() {
  const dispatch = useDispatch();
  const [matchedObstaclesClicked, setMatchedObstaclesClicked] = useState(false);
  const [similarObstaclesClicked, setSimilarObstaclesClicked] = useState(false);
  const [obstaclesWithin30mClicked, setObstaclesWithin30mClicked] =
    useState(false);
  const [sameIntegerObstaclesClicked, setSameIntegerObstaclesClicked] =
    useState(false);
  const [isFirstClickMatched, setIsFirstClickMatched] = useState(true);
  const [isFirstClickSimilar, setIsFirstClickSimilar] = useState(true);
  const [isFirstClick30m, setIsFirstClick30m] = useState(true);
  const [isFirstClickSameInteger, setIsFirstClickSameInteger] = useState(true);

  const matchedObstacles = useSelector(
    (state) => state.obstacle.matchedObstacles
  );
  const similarObstacles = useSelector(
    (state) => state.obstacle.similarObstacles
  );
  const obstaclesWithin30m = useSelector(
    (state) => state.obstacle.obstaclesWithin30m
  );
  const sameIntegerObstacles = useSelector(
    (state) => state.obstacle.sameIntegerObstacles
  );

  const showAddObstacle = useSelector((state) => state.ui.showAddObstacle);
  const loading = useSelector((state) => state.ui.loading);

  const toggleAddObstacle = () => {
    dispatch(uiActions.toggleShowAddObstacle());
    setMatchedObstaclesClicked(false);
    setSimilarObstaclesClicked(false);
    setObstaclesWithin30mClicked(false);
    setSameIntegerObstaclesClicked(false);
  };

  const handleButtonClick = (buttonType) => {
    setMatchedObstaclesClicked(false);
    setSimilarObstaclesClicked(false);
    setObstaclesWithin30mClicked(false);
    setSameIntegerObstaclesClicked(false);

    switch (buttonType) {
      case "matched":
        if (isFirstClickMatched) {
          dispatch(fetchMatchedObstacles());
          setIsFirstClickMatched(false);
        }
        setMatchedObstaclesClicked(true);
        break;
      case "similar":
        if (isFirstClickSimilar) {
          dispatch(fetchSimilarObstacles());
          setIsFirstClickSimilar(false);
        }
        setSimilarObstaclesClicked(true);
        break;
      case "within30m":
        if (isFirstClick30m) {
          dispatch(fetchObstaclesWithin30m());
          setIsFirstClick30m(false);
        }
        setObstaclesWithin30mClicked(true);
        break;
      case "sameInteger":
        if (isFirstClickSameInteger) {
          dispatch(fetchSameIntegerObstacles());
          setIsFirstClickSameInteger(false);
        }
        setSameIntegerObstaclesClicked(true);
        break;
      default:
        break;
    }
  };

  return (
    <div>
      <div>
        <button className={style.toggleButton} onClick={toggleAddObstacle}>
          Add New Obstacle
        </button>
        <button
          className={style.toggleButton}
          onClick={() => handleButtonClick("matched")}
        >
          Tamamen Eslesen Obstacle'lar
        </button>
        <button
          className={style.toggleButton}
          onClick={() => handleButtonClick("similar")}
        >
          DMS Koordinati Virgulden Sonra Tek Rakami Eslesen Obstacle'lar
        </button>
        <button
          className={style.toggleButton}
          onClick={() => handleButtonClick("sameInteger")}
        >
          DMS Koordinatindaki Tam Sayi Eslesen Obstacle'lar
        </button>
        <button
          className={style.toggleButton}
          onClick={() => handleButtonClick("within30m")}
        >
          Uzakligi 30 Metreden Az Olan Obstacle'lar
        </button>
      </div>
      {showAddObstacle && <AddObstacle />}
      {loading ? (
        <Loading />
      ) : (
        <>
          {matchedObstaclesClicked && (
            <MatchedObstacleList matchedObstacles={matchedObstacles} />
          )}

          {similarObstaclesClicked && (
            <SimilarObstacleList similarObstacles={similarObstacles} />
          )}

          {sameIntegerObstaclesClicked && (
            <SimilarObstacleList similarObstacles={sameIntegerObstacles} />
          )}

          {obstaclesWithin30mClicked && (
            <ObstaclesWithin30Meters obstaclesWithin30m={obstaclesWithin30m} />
          )}
        </>
      )}
    </div>
  );
}

export default Obstacle;
