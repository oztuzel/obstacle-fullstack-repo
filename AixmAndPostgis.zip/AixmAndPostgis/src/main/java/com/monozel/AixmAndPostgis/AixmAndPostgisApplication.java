package com.monozel.AixmAndPostgis;

import com.monozel.AixmAndPostgis.services.JavaXmlConvertService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AixmAndPostgisApplication {

	public static void main(String[] args) {
		SpringApplication.run(AixmAndPostgisApplication.class, args);
	}

}
