import { createSlice } from "@reduxjs/toolkit";
import { uiActions } from "./ui-slice";

const mapSlice = createSlice({
  name: "map",
  initialState: {
    allPoints: [],
    selectedPoint: null,
    nearestPoints: null,
    pointsWithin30m: [],
  },
  reducers: {
    replaceAllPoints(state, action) {
      state.allPoints = action.payload.allPointsData;
    },

    setSelectedPoint(state, action) {
      state.selectedPoint = action.payload.selectedPointData;
    },
    deleteSelectedPoint(state) {
      state.selectedPoint = null;
    },

    setNearestPoints(state, action) {
      state.nearestPoints = action.payload.nearestPointsData;
    },
    deleteNearestPoints(state) {
      state.nearestPoints = null;
    },

    setPointsWithin30m(state, action) {
      state.pointsWithin30m = action.payload.pointsWithin30mData;
    },
  },
});

export const fetchAllPoints = () => {
  // thunk
  return async (dispatch) => {
    const fetchData = async () => {
      const response = await fetch(
        "http://localhost:8080/test/getFeatureCollection"
      );
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      const data = await response.json();
      return data;
    };

    try {
      const allPointsData = await fetchData();
      dispatch(
        mapActions.replaceAllPoints({
          allPointsData: allPointsData || [],
        })
      );
    } catch (error) {
      console.log("Error fetching all points (Map component): " + error);
    }
  };
};

export const fetchNearestPoints = (point) => {
  return async (dispatch) => {
    const fetchData = async () => {
      const response = await fetch(
        `http://localhost:8080/obstacles/nearestPoints?obstacleId=${point.id}`
      );
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      const data = await response.json();
      return data;
    };

    try {
      const nearestPointsData = await fetchData();
      dispatch(mapActions.setSelectedPoint({ selectedPointData: point }));
      dispatch(
        mapActions.setNearestPoints({
          nearestPointsData: nearestPointsData || [],
        })
      );
    } catch (error) {
      console.log("Error fetching nearest points (Map component): " + error);
    }
  };
};

export const fetchPointsWithin30m = () => {
  return async (dispatch) => {
    const fetchData = async () => {
      dispatch(uiActions.showLoading());
      const response = await fetch(
        "http://localhost:8080/obstacles/findObstaclesWith30"
      );
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      const data = await response.json();
      return data;
    };

    try {
      const pointsWithin30mData = await fetchData();
      dispatch(uiActions.unshowLoading());
      dispatch(
        mapActions.setPointsWithin30m({
          pointsWithin30mData: pointsWithin30mData || [],
        })
      );
    } catch (error) {
      console.log("Error fetching points within 30m (Map component): " + error);
    }
  };
};

export default mapSlice;
export const mapActions = mapSlice.actions;
