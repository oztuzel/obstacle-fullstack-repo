package com.monozel.AixmAndPostgis.controllers;

import aero.aixm.message.AIXMBasicMessageType;
import com.monozel.AixmAndPostgis.entities.HGMObstacle;
import com.monozel.AixmAndPostgis.entities.Obstacle;
import com.monozel.AixmAndPostgis.repositories.ObstacleRepository;
import com.monozel.AixmAndPostgis.requests.HGMObstacleRequest;
import com.monozel.AixmAndPostgis.requests.ObstacleRequest;
import com.monozel.AixmAndPostgis.services.HGMObstacleService;
import com.monozel.AixmAndPostgis.services.JavaXmlConvertService;
import lombok.AllArgsConstructor;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.*;

import javax.xml.bind.JAXBException;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/test")
@AllArgsConstructor
public class TestController {

    private JavaXmlConvertService javaXmlConvertService;
    private ObstacleRepository obstacleRepository;
    private HGMObstacleService hgmObstacleService;

    @GetMapping("/toXml")
    public AIXMBasicMessageType convertToXml () throws JAXBException {
        return  javaXmlConvertService.obstaclesToXmlFile();
    }

    @GetMapping("/toJava")
    public AIXMBasicMessageType convertToJava () throws JAXBException {
        return javaXmlConvertService.xmlFiletoJava();
    }


    // burada obstacle table'daki geometry column olan point columndaki pointleri json db den geojson olarak aliyoruz
    // ve bunu json'a ceviriyoruz.
    @GetMapping("/getPoint")
    public String getPoint () {
        JSONArray jsonArray = new JSONArray();

        List<String> stringList = obstacleRepository.getPointsGeoJson();

        for(String s : stringList) {
            try {
                JSONObject jsonObject = new JSONObject(s);
                jsonArray.put(jsonObject);
            } catch ( JSONException e){
                e.printStackTrace();
            }
        }

        return jsonArray.toString();
    }

    @GetMapping("/getFeatures")
    public String getFeatures () {
        JSONArray jsonArray = new JSONArray();

        List<String> stringList = obstacleRepository.getGeoJsonFeatures();

        for(String s : stringList) {
            try {
                JSONObject jsonObject = new JSONObject(s);

                String geometryString = jsonObject.getString("geometry");
                JSONObject geometryObject = new JSONObject(geometryString);
                jsonObject.put("geometry", geometryObject);


                jsonArray.put(jsonObject);

            } catch ( JSONException e){
                e.printStackTrace();
            }
        }

        return jsonArray.toString();

    }


    @GetMapping("/getFeatureCollection")
    public String getFeatureCollection () {
        JSONArray jsonArray = new JSONArray();

        List<String> stringList = obstacleRepository.getFeatureCollectionInObstacle();

        for (String s : stringList) {
            try {
                JSONObject jsonObject = new JSONObject(s);

                // 'features' listesini al
                JSONArray featuresArray = jsonObject.getJSONArray("features");

                // Her bir feature için 'geometry' alanindaki string'i json objesine ceviriyoruz
                for (int i = 0; i < featuresArray.length(); i++) {
                    JSONObject featureObject = featuresArray.getJSONObject(i);

                    String geometryString = featureObject.getString("geometry");

                    JSONObject geometryObject = new JSONObject(geometryString);

                    // string'den json a donusturdugumuz yeri tekrardan geometry kismina put ile koyuyoruz.
                    featureObject.put("geometry", geometryObject);
                }

                jsonArray.put(jsonObject);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return jsonArray.toString();
    }



}

