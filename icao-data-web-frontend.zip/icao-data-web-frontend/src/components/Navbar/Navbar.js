import { useState } from "react";
import MenuIcon from "@mui/icons-material/Menu";
import CloseIcon from "@mui/icons-material/Close";
import style from "./Navbar.module.css";
import { Link } from "react-router-dom";

function Navbar() {
  const [showNav, setShowNav] = useState(false);

  const showNavbar = () => {
    setShowNav((prevState) => {
      return !prevState;
    });
  };

  let classes = showNav ? style["responsive_nav"] : style.nav;

  return (
    <header>
      <h3>Logo</h3>
      <nav className={classes}>
        <Link to="/">Home</Link>
        <Link to="/map"> Map </Link>
        <Link to="/obstacles">Obstacles</Link>
        <Link to="/signIn">Sign In</Link>
        <button
          className={`${style["nav_btn"]} ${style["nav-close-btn"]}`}
          onClick={showNavbar}
        >
          <CloseIcon />
        </button>
      </nav>
      <button
        className={!showNav ? style["nav_btn"] : style["nav_btn_closed"]}
        onClick={showNavbar}
      >
        <MenuIcon />
      </button>
    </header>
  );
}

export default Navbar;
