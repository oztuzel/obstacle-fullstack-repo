import React from "react";
import styles from "./Sidebar.module.css";
import { Link } from "react-router-dom";

const Sidebar = ({
  handleSidebar,
  selectedPoint,
  nearestPoints,
  pointsWithin30,
  handlePointsWithin30,
  handleGetAllPoints,
}) => {
  return (
    <div className={styles.sidebar}>
      <div className={styles.buttonContainer}>
        <button className={styles.commonButton} onClick={handleSidebar}>
          Kapat
        </button>
        <button className={styles.commonButton} onClick={handleGetAllPoints}>
          Tum Obstacle'lar
        </button>
        <Link to="/" className={styles.commonButton}>
          Ana Sayfa
        </Link>
        <button onClick={handlePointsWithin30} className={styles.commonButton}>
          30 Metre Yakininda Obstacle Bulunanlar
        </button>
      </div>

      {selectedPoint ? (
        <div>
          {/* <Link to="/map"> Tum obstacle'lari getir. </Link>  /// burada bir button vb tanimlayip tum obstacle'lari getirmek icin tekrar istek atma yapabiliriz. */}
          <h3>Sectigimiz Obstacle</h3>
          <p>{selectedPoint.properties.designator}</p>
          <p>-----------------------</p>
        </div>
      ) : (
        <p>
          Bir Obstacle secilmedi. Secmek icin herhangi bir marker'a tikladiktan
          sonra butona tiklayin. Bu sayede sectiginiz noktaya en yakin 10
          obstacle'i ve aralarindaki mesafe bilgilerini goreceksiniz.
        </p>
      )}

      {nearestPoints &&
        nearestPoints.map((obstacle) => (
          <div key={obstacle.obstacleRequest.latitudeDMS}>
            <p>{obstacle.obstacleRequest.designator}</p>
            <p>
              Secilen obstacle ile arasindaki mesafe:
              {Math.round(obstacle.distance)} (metre)
            </p>
            <p> -- -- </p>
          </div>
        ))}

      {pointsWithin30.length > 0 && (
        <div>
          <h3>Kendisine 30 metreden az mesafede obstacle bulunanlar:</h3>
          {pointsWithin30.map((obstacle, index) => (
            <div key={obstacle.designator}>
              <p>
                {index + 1} - {obstacle.designator}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Sidebar;
