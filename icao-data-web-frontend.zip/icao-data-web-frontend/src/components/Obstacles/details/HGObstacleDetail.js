import React from "react";

function HGObstacleDetail({ hgObstacle }) {
  return (
    <div>
      <h2>HGM Obstacle Details</h2>
      {hgObstacle && (
        <>
          <p>Obstacle Name: {hgObstacle.obstacleName}</p>
          <p>Structure Type: {hgObstacle.structureType}</p>
          <p>Height: {hgObstacle.height}</p>
          <p>Elevation: {hgObstacle.elevation}</p>
          <p>Lighting: {hgObstacle.lighting}</p>
          <p>Latitude: {hgObstacle.latitude}</p>
          <p>Latitude(DMS): {hgObstacle.latitudeDMS}</p>
          <p>Longitude: {hgObstacle.longitude}</p>
          <p>Longitude(DMS): {hgObstacle.longitudeDMS}</p>
        </>
      )}
    </div>
  );
}

export default HGObstacleDetail;
