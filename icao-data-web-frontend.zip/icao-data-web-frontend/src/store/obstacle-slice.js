import { createSlice } from "@reduxjs/toolkit";
import { uiActions } from "./ui-slice";

const obstacleSlice = createSlice({
  name: "obstacle",
  initialState: {
    matchedObstacles: [],
    similarObstacles: {},
    sameIntegerObstacles: {},
    obstaclesWithin30m: {},
  },
  reducers: {
    replaceMatchedObstacles(state, action) {
      state.matchedObstacles = action.payload.matchedObstaclesData;
    },
    replaceSimilarObstacles(state, action) {
      state.similarObstacles = action.payload.similarObstaclesData;
    },
    replaceSameIntegerObstacles(state, action) {
      state.sameIntegerObstacles = action.payload.sameIntegerObstaclesData;
    },
    replaceObstaclesWithin30m(state, action) {
      state.obstaclesWithin30m = action.payload.obstaclesWithin30mData;
    },
  },
});

export const fetchMatchedObstacles = () => {
  // bu fonksiyonumuz thunk fonksiyonudur.
  return async (dispatch) => {
    // thunk icinde return eden fonksiyon icinde dispatch argument otomatik olarak vardir zaten. import edilmesine gerek yok
    // cunku thunk fonksiyonu slice olusturdugumuz dosya icinde olusturulabilir. eger ki component de dispatch kullanacaksak useDispatch() ile dispatch olusturmamiz gerekli.
    const fetchData = async () => {
      dispatch(uiActions.showLoading());
      const response = await fetch(
        "http://localhost:8080/HGMObstacles/findEquals"
      );
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }

      const data = await response.json();
      return data;
    };

    try {
      const matchedObstaclesData = await fetchData();
      dispatch(uiActions.unshowLoading());
      dispatch(
        obstacleActions.replaceMatchedObstacles({
          matchedObstaclesData: matchedObstaclesData || [],
        })
      );
    } catch (error) {
      console.log("Error fetching matched obstacles data: " + error);
      dispatch(
        uiActions.showNotification({
          status: "error",
          title: "Error",
          message: "Fetching data failed",
        })
      );
    }
  };
};

export const fetchSimilarObstacles = () => {
  // thunk function
  return async (dispatch) => {
    const fetchData = async () => {
      dispatch(uiActions.showLoading());
      const response = await fetch(
        "http://localhost:8080/obstacles/findSimilarPoints"
      );
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }

      const data = await response.json();
      return data;
    };

    try {
      const similarObstaclesData = await fetchData();
      dispatch(uiActions.unshowLoading());
      dispatch(
        obstacleActions.replaceSimilarObstacles({
          similarObstaclesData: similarObstaclesData || {},
        })
      );
    } catch (error) {
      console.log("Error fetching similar obstacles: " + error);
      dispatch(
        uiActions.showNotification({
          status: "error",
          title: "Error",
          message: "Fetching data failed",
        })
      );
    }
  };
};

export const fetchSameIntegerObstacles = () => {
  // thunk function
  return async (dispatch) => {
    const fetchData = async () => {
      dispatch(uiActions.showLoading());

      const response = await fetch(
        "http://localhost:8080/obstacles/findPointsSameIntegerCoordinates"
      );
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }

      const data = await response.json();
      return data;
    };

    try {
      const sameIntegerObstaclesData = await fetchData();
      dispatch(uiActions.unshowLoading());
      dispatch(
        obstacleActions.replaceSameIntegerObstacles({
          sameIntegerObstaclesData: sameIntegerObstaclesData || {},
        })
      );
    } catch (error) {
      console.log("Error fetching single digit matches obstacles: " + error);
      dispatch(
        uiActions.showNotification({
          status: "error",
          title: "Error",
          message: "Fetching data failed",
        })
      );
    }
  };
};

export const fetchObstaclesWithin30m = () => {
  // bu fonksiyonumuz thunk fonksiyonudur.
  return async (dispatch) => {
    const fetchData = async () => {
      dispatch(uiActions.showLoading());
      const response = await fetch(
        "http://localhost:8080/obstacles/findObstaclesWithin30MetersForEach"
      );
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }

      const data = await response.json();
      return data;
    };

    try {
      const obstaclesWithin30mData = await fetchData();
      dispatch(uiActions.unshowLoading());
      dispatch(
        obstacleActions.replaceObstaclesWithin30m({
          obstaclesWithin30mData: obstaclesWithin30mData || {},
        })
      );
    } catch (error) {
      console.log("Error fetching obstacles within 30 meters: " + error);
      dispatch(
        uiActions.showNotification({
          status: "error",
          title: "Error",
          message: "Fetching data failed",
        })
      );
    }
  };
};

export default obstacleSlice;
export const obstacleActions = obstacleSlice.actions; // createSlice icindeki reducers yerindeki hepsi.
