import React, { useState } from "react";
import style from "./AddObstacle.module.css";

function AddObstacle() {
  const [formData, setFormData] = useState({
    name: "",
    type: "",
    lighted: "NO",
    group: "NO",
    verticalExtent: "",
    designator: "", // LTCT15 gibidir, yani obstacle id ve neye ait oldugu
    elevation: "", // 3205 ft gibi
    lightingColor: "",
    latitude: "",
    longitude: "",
  });

  const saveObstacle = () => {
    fetch("http://localhost:8080/obstacles", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        name: formData.name.toUpperCase(),
        type: formData.type.toUpperCase(),
        lighting: formData.lighted.toUpperCase(),
        group: formData.group.toUpperCase(),
        verticalExtent: formData.verticalExtent.toUpperCase(),
        designator: formData.designator.toUpperCase(),
        height: formData.elevation.toUpperCase(),
        colour: formData.lightingColor.toUpperCase(),
        latitude: formData.latitude.toUpperCase(),
        longitude: formData.longitude.toUpperCase(),
      }),
    })
      .then((res) => res.json())
      .catch((err) => console.log("error"));
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;

    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: value,
    }));
  };

  const handleIsLighted = (e) => {
    setFormData((prevFormData) => ({
      ...prevFormData,
      lighted: e.target.value,
    }));
    console.log(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // FormData ile gönderilecek verileri burada işle.
    saveObstacle();
    // setFormData({
    //   name: "",
    //   type: "",
    //   lighted: "NO",
    //   group: "NO",
    //   verticalExtent: "",
    //   designator: "", // LTCT15 gibidir, yani obstacle id ve neye ait oldugu
    //   elevation: "", // 3205 ft gibi
    //   lightingColor: "",
    //   latitude: "",
    //   longitude: "",
    // });
  };

  return (
    <form onSubmit={handleSubmit} className={style.form}>
      <div>
        <label htmlFor="name">Name:</label>
        <input
          type="text"
          id="name"
          name="name"
          value={formData.name}
          onChange={handleInputChange}
        />
      </div>
      <div>
        <label htmlFor="type">Type:</label>
        <input
          type="text"
          id="type"
          name="type"
          value={formData.type}
          onChange={handleInputChange}
        />
      </div>
      <div>
        <label htmlFor="group">Group:</label>
        <input
          type="text"
          id="group"
          name="group"
          value={formData.group}
          onChange={handleInputChange}
        />
      </div>
      <div>
        <label htmlFor="verticalExtent">Vertical Extent (ft):</label>
        <input
          type="text"
          id="verticalExtent"
          name="verticalExtent"
          value={formData.verticalExtent}
          onChange={handleInputChange}
        />
      </div>
      <div>
        <label htmlFor="designator">Designator:</label>
        <input
          type="text"
          id="designator"
          name="designator"
          value={formData.designator}
          onChange={handleInputChange}
        />
      </div>
      <div>
        <label htmlFor="latitude">Latitude</label>
        <input
          type="text"
          id="latitude"
          name="latitude"
          value={formData.latitude}
          onChange={handleInputChange}
        />
      </div>
      <div>
        <label htmlFor="longitude">Longitude</label>
        <input
          type="text"
          id="longitude"
          name="longitude"
          value={formData.longitude}
          onChange={handleInputChange}
        />
      </div>
      <div>
        <label htmlFor="elevation">Elevation or Height(ft):</label>
        <input
          type="text"
          id="elevation"
          name="elevation"
          value={formData.elevation}
          onChange={handleInputChange}
        />
      </div>
      <div>
        <label>Is lighted?</label>
        <select id="options" name="options" onChange={handleIsLighted}>
          <option value={"NO"}>No</option>
          <option value={"YES"}>Yes</option>
        </select>
      </div>
      <div>
        <label htmlFor="lightingColor">Lighting Color:</label>
        <input
          type="text"
          id="lightingColor"
          name="lightingColor"
          value={formData.lightingColor}
          onChange={handleInputChange}
        />
      </div>

      <button type="submit">Submit</button>
    </form>
  );
}

export default AddObstacle;
