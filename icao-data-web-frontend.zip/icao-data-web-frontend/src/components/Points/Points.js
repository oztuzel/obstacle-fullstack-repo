import React from 'react'

function Points() {
  return (
    <div>
      Points
    </div>
  )
}

export default Points