import React, { useState } from "react";
import Modal from "./modal/Modal";

function RowObstacle({ obstacleId, hgObstacleId }) {
  const [modalOpen, setModalOpen] = useState(false);
  const [obstacleDetails, setObstacleDetails] = useState(null);
  const [hgObstacleDetails, setHgObstacleDetails] = useState(null);

  const openModal = async () => {
    try {
      const [obstacleResponse, hgObstacleResponse] = await Promise.all([
        fetch(`http://localhost:8080/obstacles/${obstacleId}`),
        fetch(`http://localhost:8080/HGMObstacles/${hgObstacleId}`),
      ]);

      if (!obstacleResponse.ok) {
        throw new Error(`HTTP error! Status: ${obstacleResponse.status}`);
      }
      const obstacleData = await obstacleResponse.json();
      setObstacleDetails(obstacleData);

      if (!hgObstacleResponse.ok) {
        throw new Error(`HTTP error! Status: ${hgObstacleResponse.status}`);
      }
      const hgObstacleData = await hgObstacleResponse.json();
      setHgObstacleDetails(hgObstacleData);

      setModalOpen(true);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const closeModal = () => {
    setModalOpen(false);
  };

  return (
    <>
      <tr onClick={openModal}>
        <td>{obstacleId}</td>
        <td>{hgObstacleId}</td>
      </tr>
      {modalOpen && (
        <Modal
          obstacle={obstacleDetails}
          hgObstacle={hgObstacleDetails}
          closeModal={closeModal}
        />
      )}
    </>
  );
}

export default RowObstacle;
