import React, { useState } from "react";
import ModalSimilarObstaclesRow from "../modal/ModalSimilarObstaclesRow";

function ObstaclesWithin30Meters({ obstaclesWithin30m }) {
  const itemsPerPage = 50; // Her sayfada gösterilecek öğe sayısı
  const [currentPage, setCurrentPage] = useState(1);
  const [obstacleData, setObstacleData] = useState(null);
  const [hgObstacleData, setHgObstacleData] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const similarObstacleKeys = Object.keys(obstaclesWithin30m);
  const currentItems = similarObstacleKeys
    .slice(indexOfFirstItem, indexOfLastItem)
    .map((obstacleId) => ({
      obstacleId,
      obstacleIds: obstaclesWithin30m[obstacleId],
    }));

  const totalPages = Math.ceil(
    Object.keys(obstaclesWithin30m).length / itemsPerPage
  );

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const fetchObstacleData = async (obstacleId) => {
    try {
      // /obstacles/{obstacleId} için istek gönder
      const obstacleResponse = await fetch(
        `http://localhost:8080/obstacles/${obstacleId}`
      );
      const obstacleData = await obstacleResponse.json();
      setObstacleData(obstacleData);
      // console.log("Obstacle Data:", obstacleData);
    } catch (error) {
      console.error("Error fetching obstacle data:", error);
    }
  };

  const fetchHgObstacleData = async (obstacleId) => {
    try {
      // /hgmobstacles/{hgObstacleId} için istek gönder
      const hgObstacleResponse = await fetch(
        `http://localhost:8080/obstacles/${obstacleId}`
      );
      const hgObstacleData = await hgObstacleResponse.json();
      setHgObstacleData((prevData) => [...prevData, hgObstacleData]);
      // console.log("HG Obstacle Data:", hgObstacleData);
    } catch (error) {
      console.error("Error fetching HG obstacle data:", error);
    }
  };

  const handleRowClick = async (obstacleId, obstacleIds) => {
    // /obstacles/{obstacleId} için istek gönderiyoruz
    fetchObstacleData(obstacleId);

    // /hgmobstacles/{hgObstacleId} için her bir hgObstacleId için istek gönderiyoruz
    if (Array.isArray(obstacleIds)) {
      obstacleIds.forEach((obstacleId) => {
        fetchHgObstacleData(obstacleId);
      });
    }

    // tiklandiginda kutucuk acilacak ve datalari gosterecez.
    setIsModalOpen(true);
  };

  const closeModal = () => {
    // kutucuku kapatma yeri
    setIsModalOpen(false);
    setObstacleData(null);
    setHgObstacleData([]);
  };

  return (
    <div>
      <h2>Obstacles Within 30m:</h2>
      <table>
        <thead>
          <tr>
            <th>ENR 5.4 Obstacle ID</th>
            <th>Obstacles within 30 meters</th>
          </tr>
        </thead>
        <tbody>
          {currentItems.map(({ obstacleId, obstacleIds }, index) => (
            <tr
              key={index}
              onClick={() => handleRowClick(obstacleId, obstacleIds)}
            >
              <td>{obstacleId}</td>
              <td>{obstacleIds.join(", ")}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div>
        <p>
          Page {currentPage} of {totalPages}
        </p>
        <button
          onClick={() => handlePageChange(currentPage - 1)}
          disabled={currentPage === 1}
        >
          Previous
        </button>
        <button
          onClick={() => handlePageChange(currentPage + 1)}
          disabled={currentPage === totalPages}
        >
          Next
        </button>
      </div>

      {isModalOpen && (
        <ModalSimilarObstaclesRow
          obstacleData={obstacleData}
          hgObstacleData={hgObstacleData}
          closeModal={closeModal}
        />
      )}
    </div>
  );
}

export default ObstaclesWithin30Meters;
