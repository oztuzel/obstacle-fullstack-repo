import React from 'react';

function EditPoints() {
  return (
    <div>EditPoints</div>
  )
}

export default EditPoints