import { createSlice } from "@reduxjs/toolkit";

const uiSlice = createSlice({
  name: "ui",
  initialState: {
    showAddObstacle: false,
    loading: false,
    sideBarOpen: false,
    notification: null,
  },
  reducers: {
    toggleShowAddObstacle(state) {
      state.showAddObstacle = !state.showAddObstacle; // state'i mutate eder gibi gozuksede arka planda yapilan islemlerden dolayi mutate olmaz. bu islemi burada dispatchsiz bu sekilde yapabiliriz.
    },
    showLoading(state) {
      state.loading = true;
    },
    unshowLoading(state) {
      state.loading = false;
    },
    toggleSideBarOpen(state) {
      state.sideBarOpen = !state.sideBarOpen;
    },
    showNotification(state, action) {
      state.notification = {
        status: action.payload.status,
        title: action.payload.title,
        message: action.payload.message,
      };
    },
  },
});

export const uiActions = uiSlice.actions;
export default uiSlice;
