import React, { useEffect, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import icon from "leaflet/dist/images/marker-icon.png";
import selectedIcon from "../../images/map-marker.svg";
import Sidebar from "./Sidebar";
import style from "./Map.module.css";
import { useSelector, useDispatch } from "react-redux";
import {
  fetchAllPoints,
  fetchNearestPoints,
  fetchPointsWithin30m,
  mapActions,
} from "../../store/map-slice";
import Loading from "../UI/Loading";

const myIcon = L.icon({
  iconUrl: icon,
  iconSize: [10, 15],
  // iconAnchor: [22, 94],
  // popupAnchor: [-15, -85],
});

const selectedIconRed = L.icon({
  iconUrl: selectedIcon,
  iconSize: [20, 30],
});

function Map() {
  const dispatch = useDispatch();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [isAllPointsClicked, setIsAllPointsClicked] = useState(true);
  const [isPointsWithin30mClicked, setIsPointsWithin30mClicked] =
    useState(false);
  const [hasSelectedPoint, setHasSelectedPoint] = useState(false);
  const [isFirstClicked30m, setIsFirstClicked30m] = useState(true);

  const allPoints = useSelector((state) => state.map.allPoints);
  const nearestPoints = useSelector((state) => state.map.nearestPoints);
  const selectedPoint = useSelector((state) => state.map.selectedPoint);
  const pointsWithin30m = useSelector((state) => state.map.pointsWithin30m);

  const loading = useSelector((state) => state.ui.loading);

  useEffect(() => {
    dispatch(fetchAllPoints());
  }, [dispatch]);

  const handleGetAllPoints = () => {
    dispatch(mapActions.deleteNearestPoints());
    dispatch(mapActions.deleteSelectedPoint());
    setIsAllPointsClicked(true);
    setHasSelectedPoint(false);
    setIsPointsWithin30mClicked(false);
  };

  const handleGetNearestPoints = async (point) => {
    dispatch(fetchNearestPoints(point));
    setIsAllPointsClicked(false);
    setIsPointsWithin30mClicked(false);
    setHasSelectedPoint(true);
  };

  const handlePointsWithin30 = () => {
    setIsAllPointsClicked(false);
    setHasSelectedPoint(false);
    setIsPointsWithin30mClicked(true);
    if (isFirstClicked30m) {
      dispatch(fetchPointsWithin30m());
      setIsFirstClicked30m(false);
    }
    dispatch(mapActions.deleteSelectedPoint());
    dispatch(mapActions.deleteNearestPoints());
  };

  const handleSidebar = () => {
    setSidebarOpen((state) => !state);
  };

  return (
    <div>
      {loading && <Loading />}
      <MapContainer
        center={[38.9334, 34.8597]}
        zoom={7}
        scrollWheelZoom={true}
        style={{ zIndex: "0", position: "relative", height: "100vh" }}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          // bounds={[
          //   [35.0, 26.0], // Alt sol köşe (Lat, Lon)
          //   [42.1, 45.0], // Üst sağ köşe (Lat, Lon)   haritayi bu koordinatlar arasiyla sinirlandirmak istersek
          // ]}
        />

        {/* haritadaki tum noktalarimiz */}
        {isAllPointsClicked &&
          allPoints?.map((feature) =>
            feature.features.map((f) => (
              <Marker
                key={f.id}
                position={f.geometry.coordinates} // Leaflet'in position formati: [lat, lon]
                icon={myIcon}
              >
                <Popup>
                  <div>
                    <h3>{f.properties.designator}</h3>
                    <p>Colour: {f.properties.colour || "Non-Coloured"}</p>
                    <p>Type Name: {f.properties.type_name}</p>
                    <p>LatitudeDMS: {f.properties.latitudedms}</p>
                    <p>Latitude (Decimal): {f.geometry.coordinates[0]}</p>
                    <p>LongitudeDMS: {f.properties.longitudedms}</p>
                    <p>lighting: {f.properties.lighting}</p>
                    <p>Longitude (Decimal): {f.geometry.coordinates[1]}</p>
                    <button onClick={() => handleGetNearestPoints(f)}>
                      Select This and Get Nearest 10 Obstacles
                    </button>
                  </div>
                </Popup>
              </Marker>
            ))
          )}

        {/* Seçilen nokta için marker ve popup */}
        {hasSelectedPoint && selectedPoint && (
          <Marker
            position={selectedPoint.geometry.coordinates}
            icon={selectedIconRed}
            key={selectedPoint.id}
          >
            <Popup>
              <div>
                <h3>{selectedPoint.properties.designator}</h3>
                <p>
                  Colour: {selectedPoint.properties.colour || "Non-Coloured"}
                </p>
                <p>Type Name: {selectedPoint.properties.type_name}</p>
                <p>LatitudeDMS: {selectedPoint.properties.latitudedms}</p>
                <p>
                  Latitude (Decimal): {selectedPoint.geometry.coordinates[0]}
                </p>
                <p>LongitudeDMS: {selectedPoint.properties.longitudedms}</p>
                <p>lighting: {selectedPoint.properties.lighting}</p>
                <p>
                  Longitude (Decimal): {selectedPoint.geometry.coordinates[1]}
                </p>
              </div>
            </Popup>
          </Marker>
        )}

        {/* en yakin 10 point'i render ediyoruz */}
        {hasSelectedPoint &&
          selectedPoint &&
          nearestPoints?.map((obstacle, index) => (
            <Marker
              key={index}
              position={[
                obstacle.obstacleRequest.latitude,
                obstacle.obstacleRequest.longitude,
              ]} // Leaflet'in position formati: [lat, lon]
              icon={myIcon}
            >
              <Popup>
                <div>
                  <h3>{obstacle.obstacleRequest.designator}</h3>
                  <p>Aixm Name: {obstacle.obstacleRequest.aixm_name}</p>
                  <p>Type: {obstacle.obstacleRequest.type}</p>
                  <p>Elevation: {obstacle.obstacleRequest.elevation}</p>
                  <p>Height: {obstacle.obstacleRequest.height}</p>
                  <p>Lighting: {obstacle.obstacleRequest.lighting}</p>
                  <p>
                    Colour: {obstacle.obstacleRequest.colour || "Non-Coloured"}
                  </p>
                  <p>Latitude (Decimal): {obstacle.obstacleRequest.latitude}</p>
                  <p>Latitude (DMS): {obstacle.obstacleRequest.latitudeDMS}</p>
                  <p>
                    Longitude (Decimal): {obstacle.obstacleRequest.longitude}
                  </p>
                  <p>
                    Longitude (DMS) : {obstacle.obstacleRequest.longitudeDMS}
                  </p>
                </div>
              </Popup>
            </Marker>
          ))}

        {isPointsWithin30mClicked &&
          pointsWithin30m?.map((obstacle, index) => (
            <Marker
              key={index}
              position={[obstacle.latitude, obstacle.longitude]} // Leaflet'in position formati: [lat, lon]
              icon={myIcon}
            >
              <Popup>
                <div>
                  <h3>{obstacle.designator}</h3>
                  <p>Aixm Name: {obstacle.aixm_name}</p>
                  <p>Type: {obstacle.type}</p>
                  <p>Elevation: {obstacle.elevation}</p>
                  <p>Height: {obstacle.height}</p>
                  <p>Lighting: {obstacle.lighting}</p>
                  <p>Colour: {obstacle.colour || "Non-Coloured"}</p>
                  <p>Latitude (Decimal): {obstacle.latitude}</p>
                  <p>Latitude (DMS): {obstacle.latitudeDMS}</p>
                  <p>Longitude (Decimal): {obstacle.longitude}</p>
                  <p>Longitude (DMS) : {obstacle.longitudeDMS}</p>
                </div>
              </Popup>
            </Marker>
          ))}
      </MapContainer>

      {/* sectigimiz obstacle ile en yakin 10 obstacle arasindaki mesafe bilgisini ogrenecegimiz sidebar */}
      {sidebarOpen ? (
        <Sidebar
          handleSidebar={handleSidebar}
          selectedPoint={selectedPoint || null}
          nearestPoints={nearestPoints || null}
          pointsWithin30={pointsWithin30m}
          handlePointsWithin30={handlePointsWithin30}
          handleGetAllPoints={handleGetAllPoints}
        />
      ) : (
        <button className={style.openButton} onClick={handleSidebar}>
          Open Side Bar
        </button>
      )}
    </div>
  );
}

export default Map;
